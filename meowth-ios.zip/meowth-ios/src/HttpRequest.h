//
//  HttpRequest.h
//  meowth
//
//  Created by Yacine Rezgui on 27/07/2015.
//  Copyright (c) 2015 Yacine Rezgui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCTBridgeModule.h"
#import "RCTLog.h"

@interface HttpRequest : NSObject <RCTBridgeModule>

@end
