# Assets

- http://soundbible.com/2067-Blop.html
- http://soundbible.com/819-Checkout-Scanner-Beep.html