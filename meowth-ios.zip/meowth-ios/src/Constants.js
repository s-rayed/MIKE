module.exports = {
  RECORD_FILE: '/voice.pcm',
  STATUS: {
    WAITING: 'WAITING',
    RECORDING: 'RECORDING',
    RECOGNIZING: 'RECOGNIZING',
  },
  API_URL: 'https://stream.watsonplatform.net/speech-to-text/api/v1/recognize?continuous=true',
  MIME_TYPE: 'audio/l16; rate=48000; channels=2',
  USERNAME: '975ae5f9-f834-46a5-9538-836b61c6d326',
  PASSWORD: 'Nzz87JM6cGMJ',
};