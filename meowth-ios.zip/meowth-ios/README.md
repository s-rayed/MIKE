# Meowth iOS
iOS app that transcript your voice with IBM Watson Cloud.

### Articles

- https://medium.com/dev-rocket/hybrid-development-a-complete-fail-95927aa37571
- https://medium.com/dev-rocket/dev-with-react-native-part-1-83c8c7fe9c62

![Screenshot](screenshot-multi.png)
